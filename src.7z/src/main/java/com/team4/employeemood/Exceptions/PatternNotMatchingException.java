package com.team4.employeemood.Exceptions;

public class PatternNotMatchingException extends Throwable {
    public PatternNotMatchingException(String message) { super (message);}
}