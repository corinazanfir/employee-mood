package com.team4.employeemood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeemoodApplicationTests {

	@Test
	void contextLoads() {
	}

}
